library(testthat)

test_check("KRIS")
