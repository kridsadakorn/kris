## 07/04/2018
* Add PCA 
...DONE
* plot 2D and 3D
* add shiny package

## 24/04/2018
* Recheck example for cal.PC.linear, not correct yet. 
...DONE

## 25/04/2018
* create unit tests 
...DONE
* recheck all examples again
...DONE
* To solve 'Warning: unknown option ‘--resave-data=gzip’'
save(simsnp,sample_labels, file='example_SNP.rda', compress='bzip2')
...DONE

##04/05/2018
* Use functions in testthat to check all parameters to functions, idea to create useful function in order to check
** Integer between X and Y
** Double between X and Y
** String 
** File location
** Directory location
** TRUE or FALSE
** Specified words
** List with expected objects
** Vector with specific class
** Matrix with specific class
** Data frame with specific class

##25/05/2018
* Export colors and patterns to be data objects and write the function to show the patterns and colors

##13/06/2018
*Idea to improve the function cal.projected.pc, the result of this function should have the same order of the input. Now the data are sorted according to case and control
*Idea for plot3views, it should be better to separate color and pch. Also check pch and color format 'pink', 0, or '#378323' should work in all kinds of format

##02/07/2018
*for read.bed, improve the function to support bed format from PLINK 1.9. The detail is here: https://www.cog-genomics.org/plink/1.9/formats#bed

##27/07/2018
*Check EMCluster in order to compare to RubikClust or even integrate to IPCAPS. https://cran.r-project.org/web/packages/EMCluster/index.html

##27/07/2018
* rewrite the help page of plot3view

##10/05/2019
* add the stacked-stone plot 
* for Rubikclust, make it available for all dimensions (except 1D)
* perhaps make it more like, randomly/entirely calculate to find the largest space first, to select that one as the fist axis to rotate (idea like Random Forest). Or make it into 2 modes, sequential mode from the first to the last column, random mode like Random Forest, best mode to select the best setting but it will be slowest!


