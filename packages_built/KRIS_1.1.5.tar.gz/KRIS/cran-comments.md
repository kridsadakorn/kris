## Test environments
* OS X 10.13.3, R 3.4.3
* Scientific Linux 7.4, R 3.4.4
* win-builder (devel, release, and old release)

## R CMD check results for OS X

0 errors | 0 warnings | 0 notes

## R CMD check results for Scientific Linux

0 errors | 0 warnings | 2 notes

### NOTES:
* Maintainer: ‘Kridsadakorn Chaichoompu <kridsadakorn@biostatgen.org>’
    * New maintainer: Kridsadakorn Chaichoompu <kridsadakorn@biostatgen.org>
    * Old maintainer(s): Kridsadakorn Chaichoompu <kridsadakorn.chaichoompu@gmail.com>
    * In fact, the email address was updated.  

* installed size is 20.1Mb

## R CMD check results for win-builder

0 errors | 0 warnings | 2 notes

### NOTES:
* Maintainer: ‘Kridsadakorn Chaichoompu <kridsadakorn@biostatgen.org>’
    * New maintainer: Kridsadakorn Chaichoompu <kridsadakorn@biostatgen.org>
    * Old maintainer(s): Kridsadakorn Chaichoompu <kridsadakorn.chaichoompu@gmail.com>
    * In fact, the email address was updated.  

*  Possibly mis-spelled words in DESCRIPTION:
    *  Bioinformatic (2:52)
    *  Fst (6:228)
    *  PLINK (6:303)
    *  bioinformatic (6:61)
    *  nucleotide (6:161)
    *  polymorphism (6:172)
    * In fact, these words do exist in biology and bioinformatic areas.
